/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package av1.pm;

import java.util.HashMap;

/**
 *
 * @author 1638220
 */
public class Procedimento {
    private String nome;
    private String duracao;
    private double valor;
    private int complexidade;
    private HashMap<Procedimento, Atendimento> atendimentos;
    
    public Procedimento(){}
    
    public Procedimento(String nome, String duracao, double valor, int complexidade){
        this.nome = nome;
        this.duracao = duracao;
        this.valor = valor;
        this.complexidade = complexidade;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the duracao
     */
    public String getDuracao() {
        return duracao;
    }

    /**
     * @param duracao the duracao to set
     */
    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    /**
     * @return the valor
     */
    public double getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(double valor) {
        this.valor = valor;
    }

    /**
     * @return the complexidade
     */
    public int getComplexidade() {
        return complexidade;
    }

    /**
     * @param complexidade the complexidade to set
     */
    public void setComplexidade(int complexidade) {
        this.complexidade = complexidade;
    }

    /**
     * @return the atendimentos
     */
    public HashMap<Procedimento, Atendimento> getAtendimentos() {
        return atendimentos;
    }

    /**
     * @param atendimentos the atendimentos to set
     */
    public void setAtendimentos(HashMap<Procedimento, Atendimento> atendimentos) {
        this.atendimentos = atendimentos;
    }
    
    
}
