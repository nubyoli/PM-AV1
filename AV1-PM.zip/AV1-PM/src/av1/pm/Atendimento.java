/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package av1.pm;

import java.util.Scanner;

/**
 *
 * @author 1638220
 */
public class Atendimento {
    private int cod;
    private String nomeAnimal;
    private String especie;
    private String tutor;
    private String data;
    private String horario;
    private String status;
    private String observacoes;
    private Procedimento procedimento;

    public Atendimento(){}
    
    private Atendimento(String nomeAnimal, String especie, String tutor, String data, String horario, String status, String observacoes, Procedimento procedimento){
        this.nomeAnimal = nomeAnimal;
        this.especie = especie;
        this.data = data;
        this.tutor = tutor;
        this.horario = horario;
        this.status = status;
        this.observacoes = observacoes;
        this.procedimento = procedimento;
    }
    
    public void exibirDetalhes(){
        System.out.println("----- ATENDIMENTO -----");
        System.out.println("Animal: " + nomeAnimal);
        System.out.println("Especie: " + especie);
        System.out.println("Data: " + data);
        System.out.println("Tutor: " + tutor);
        System.out.println("Horario: " + horario);
        System.out.println("Status: " + status);
        System.out.println("Observações: " + observacoes);
        System.out.println("Procedimento: " + procedimento);
    }
   
    /**
     * @return the cod
     */
    public int getCod() {
        return cod;
    }

    /**
     * @param cod the cod to set
     */
    public void setCod(int cod) {
        this.cod = cod;
    }

    /**
     * @return the nomeAnimal
     */
    public String getNomeAnimal() {
        return nomeAnimal;
    }

    /**
     * @param nomeAnimal the nomeAnimal to set
     */
    public void setNomeAnimal(String nomeAnimal) {
        this.nomeAnimal = nomeAnimal;
    }

    /**
     * @return the especie
     */
    public String getEspecie() {
        return especie;
    }

    /**
     * @param especie the especie to set
     */
    public void setEspecie(String especie) {
        this.especie = especie;
    }

    /**
     * @return the tutor
     */
    public String getTutor() {
        return tutor;
    }

    /**
     * @param tutor the tutor to set
     */
    public void setTutor(String tutor) {
        this.tutor = tutor;
    }

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * @return the horario
     */
    public String getHorario() {
        return horario;
    }

    /**
     * @param horario the horario to set
     */
    public void setHorario(String horario) {
        this.horario = horario;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the observacoes
     */
    public String getObservacoes() {
        return observacoes;
    }

    /**
     * @param observacoes the observacoes to set
     */
    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    /**
     * @return the procedimento
     */
    public Procedimento getProcedimento() {
        return procedimento;
    }

    /**
     * @param procedimento the procedimento to set
     */
    public void setProcedimento(Procedimento procedimento) {
        this.procedimento = procedimento;
    }
    
    
}
