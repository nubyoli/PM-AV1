/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package av1.pm;

import java.util.ArrayList;

/**
 *
 * @author 1638220
 */
public class Sala {
    private int num;
    private int bloco;
    private int capacidadeMax;
    private String tipoSala;
    private Veterinario veterinario;
    private ArrayList<Atendimento> atendimentos;
    
    public Sala(){}
    
    public Sala(int num, int bloco, int capacidadeMax, String tipoSala, Veterinario veterinario){
        this.num = num;
        this.bloco = bloco;
        this.capacidadeMax = capacidadeMax;
        this.tipoSala = tipoSala;
        this.veterinario = veterinario;
        this.atendimentos = new ArrayList();
    }

    /**
     * @return the num
     */
    public int getNum() {
        return num;
    }

    /**
     * @param num the num to set
     */
    public void setNum(int num) {
        this.num = num;
    }

    /**
     * @return the bloco
     */
    public int getBloco() {
        return bloco;
    }

    /**
     * @param bloco the bloco to set
     */
    public void setBloco(int bloco) {
        this.bloco = bloco;
    }

    /**
     * @return the capacidadeMax
     */
    public int getCapacidadeMax() {
        return capacidadeMax;
    }

    /**
     * @param capacidadeMax the capacidadeMax to set
     */
    public void setCapacidadeMax(int capacidadeMax) {
        this.capacidadeMax = capacidadeMax;
    }

    /**
     * @return the tipoSala
     */
    public String getTipoSala() {
        return tipoSala;
    }

    /**
     * @param tipoSala the tipoSala to set
     */
    public void setTipoSala(String tipoSala) {
        this.tipoSala = tipoSala;
    }

    /**
     * @return the veterinario
     */
    public Veterinario getVeterinario() {
        return veterinario;
    }

    /**
     * @param veterinario the veterinario to set
     */
    public void setVeterinario(Veterinario veterinario) {
        this.veterinario = veterinario;
    }

    /**
     * @return the atendimentos
     */
    public ArrayList<Atendimento> getAtendimentos() {
        return atendimentos;
    }

    /**
     * @param atendimentos the atendimentos to set
     */
    public void setAtendimentos(ArrayList<Atendimento> atendimentos) {
        this.atendimentos = atendimentos;
    }
    
    
}
