/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package av1.pm;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author 1638220
 */
public class AV1PM {

    /**
     * @param args the command line arguments
     */
    Scanner input = new Scanner(System.in);
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Veterinario v1 = new Veterinario();
        Veterinario v2 = new Veterinario();
        Veterinario v3 = new Veterinario();
        
        Sala s1 = new Sala();
        Sala s2 = new Sala();
        Sala s3 = new Sala();
        
        int opcao = 0;
        while(opcao != 8){
            System.out.println("\n---------------- MENU PRINCIPAL ----------------");
            System.out.println("1. Cadastrar Atendimento");
            System.out.println("2. Associar um veterinário a uma sala");
            System.out.println("3. Atribuir atendimento a uma sala");
            System.out.println("4. Exibir todos os atendimentos atribuídos a uma sala específica");
            System.out.println("5. Informar a quantidade total de atendimentos finalizados por cada sala");
            System.out.println("6. Buscar atendimentos por status.");
            System.out.println("7. Exibir os detalhes completos de um atendimento específico");
            System.out.println("8. Finalizar");
            
            System.out.print("\nEscolha uma opção: ");

            opcao = input.nextInt();
            input.nextLine();
            
            switch (opcao) {

                case 1:
                    cadastrarAtendimento();
                    break;

                case 2:
                    associaVeterinario(v1);
                    break;

                case 3:
                    //atribuiAtendimento();
                    break;

                case 4:
                    exibeAtendimento();
                    break;

                case 5:
                    atendimentosPorSala();
                    break;

                case 6:
                    atendimentosPorStatus();
                    break;

                case 7:
                    detalhesAtendimento();
                    break;

                case 8:
                    System.out.println(
                            "\nSessão finalizada");
                    break;

                default:
                    System.out.println(
                            "\nOpção inválida!");
            }
        }
        
        input.close();
    }
    
    public static void cadastrarAtendimento(){
        Scanner input = new Scanner(System.in);
        
        Atendimento atendimento = new Atendimento();
        System.out.println("Nome do animal: ");
        atendimento.setNomeAnimal(input.nextLine());
        
        System.out.println("Especie: ");
        atendimento.setEspecie(input.nextLine());
        
        System.out.println("Tutor: ");
        atendimento.setTutor(input.nextLine());
        
        System.out.println("Data: ");
        atendimento.setData(input.nextLine());
        
        System.out.println("Horario: ");
        atendimento.setHorario(input.nextLine());
        
        System.out.println("Status: ");
        atendimento.setStatus(input.nextLine());
        
        System.out.println("Observacoes: ");
        atendimento.setObservacoes(input.nextLine());
        
        /*System.out.println("Procedimento: ");
        atendimento.setProcedimento(input.());*/
    }
    
    public static void associaVeterinario(Veterinario veterinario){
        Sala sala = new Sala();
        sala.setVeterinario(veterinario);
    }
    
    public static void atribuiAtendimento(ArrayList<Atendimento> atendimentos){
        Sala sala = new Sala();
        sala.setAtendimentos(atendimentos);
    }
    
    public static void exibeAtendimento(){
        
    }
    
    public static void atendimentosPorSala(){
        System.out.println("Informe o numero da sala: ");
        //int sala = input.nextInt();
        
    }
    
    public static void atendimentosPorStatus(){
        
    }
    
    public static void detalhesAtendimento(){}
}
